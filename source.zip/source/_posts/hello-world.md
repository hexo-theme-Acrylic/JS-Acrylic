---
title: 你好-Acrylic
cover: 'https://www.z4a.net/images/2023/02/10/2wXMcV.jpg'
tags:
  - Acrylic
  - 主题文档
top_img: 'https://www.z4a.net/images/2023/02/10/2wXMcV.jpg'
categories: Acrylic
abbrlink: 46819
date: 2023-02-10 17:48:38
---
# 你好-Acrylic

![1](https://ldbbs.ldmnq.com/bbs/topic/attachment/2023-2/561ba70e-8697-4982-a57f-203aaa7d7667.png)
![2](https://tucdn.wpon.cn/2023/02/08/16fa1019080c7.png)
![3](https://tucdn.wpon.cn/2023/02/08/2b008821d75ce.png)
![4](https://tucdn.wpon.cn/2023/02/08/973d237cbb4f7.png)
![5](https://tucdn.wpon.cn/2023/02/08/c4f72037d1257.png)

预览: 原始主题 [HEO](https://blog.zhheo.com/) || 👍 [满心](https://blog.lovelu.top/)  ||  🤞 [Jayhrn](https://blog.jayhrn.com/)

## ✨ 贡献者
> 欢迎你加入我们Acrylic组织
![](/img/qqgroup.webp)

### 参与开发
[@Marcus](https://github.com/MarcusYYDS)
[@Shine Yu](https://github.com/ShineYull)
[Acozycotage](https://github.com/Acozycotage)
### 服务器提供和测试
[@满心](https://github.com/helloqibin)
### 相关帮助
暂无
### 大佬专座
[@张洪HEO](https://github.com/zhheo)

## 开发进度
50%